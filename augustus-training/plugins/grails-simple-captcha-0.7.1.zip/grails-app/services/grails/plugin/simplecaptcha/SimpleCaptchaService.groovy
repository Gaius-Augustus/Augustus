package grails.plugin.simplecaptcha

import org.springframework.web.context.request.RequestContextHolder


class SimpleCaptchaService {

    static final CAPTCHA_SOLUTION_ATTR = 'captcha'
    static final CAPTCHA_IMAGE_ATTR = 'captchaImage'

    /**
     * Indicates if the CAPTCHA was solved correctly
     * @param captchaSolution The CAPTCHA solution provided by the user
     * @return Indicates whether the CAPTCHA challenge was passed
     */
    boolean validateCaptcha(String captchaSolution) {

        def session = RequestContextHolder.currentRequestAttributes().session
        String solution = session[CAPTCHA_SOLUTION_ATTR]

        // remove the CAPTCHA so a new one will be generated next time one is requested
        session.removeAttribute(CAPTCHA_SOLUTION_ATTR)
        session.removeAttribute(CAPTCHA_IMAGE_ATTR)

        captchaSolution ? solution?.compareToIgnoreCase(captchaSolution) == 0 : false
    }
}
