/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import org.codehaus.groovy.grails.commons.GrailsClassUtils

class Axis2GrailsPlugin {
    def author = "Eranga Jayasundera"
    def authorEmail = "erangaj@gmail.com"
    def title = "Adds Web Service support for Grails services using Apaxhe Axis2."
    def description = '''\
Axis2 plugin allows to expose Grails service classes as Web Services. It is
Based on the WSO2 Web Service Framework for Spring.
'''
    def documentation = "http://www.grails.org/Apache+Axis2+Plugin"
    def version = '0.7.0'
    //def loadAfter = ['services']
    //def observe = ['services','hibernate']
    //def dependsOn = [services: '1.0']                
    def watchedResources = ["file:./grails-app/services/**/*Service.groovy",
	"file:./plugins/*/grails-app/services/**/*Service.groovy"]
    
    def doWithSpring = {
        if(application.serviceClasses) {
            application.serviceClasses.each { service ->
                def serviceClass = service.getClazz()
                def exposes = GrailsClassUtils.getStaticPropertyValue(serviceClass, 'expose')
                if(exposes!=null && exposes.contains('axis2')) {
                    def wsName = service.propertyName
                    wsName = wsName.substring(0, wsName.lastIndexOf("Service"))
                    def springWS = wsName + "SpringWebService"
                    "${springWS}"(org.grails.axis2.GrailsWebService) {
                        serviceBean = ref("${service.propertyName}")
                        serviceName = wsName
                        services = ref("services")
                    }
                }
            }		
        }
        
        "services"(org.wso2.spring.ws.WebServices) {
            services = []
        }
        
        "axisConfig"(org.wso2.spring.ws.SpringAxisConfiguration) {
            parameters = [ref("hd"), ref("hu"), ref("eMTOM"), ref("eSwA"),
                ref("timeOut"), ref("stacktrace"), ref("drillFaultReason"),
                ref("username"), ref("passwd"), ref("disRest")]
            messageReceivers = [ref("axis2MsgReceiverIN"),
                ref("axis2MsgReceiverINOUT"), ref("axis2MsgReceiverIN2"),
                ref("axis2MsgReceiverINOUT2")]
            messageFormatters = [ref("axis2MsgFormatterURL"),
                ref("axis2MsgFormatterForm"), ref("axis2MsgFormatterXML")]
            messageBuilders = [ref("axis2MsgBuilderURL"),
                ref("axis2MsgBuilderForm"), ref("axis2MsgBuilderXML")]
            transportReceivers = [ref("axis2TransportReceiver")]
            transportSenders = [ref("axis2TransportSenderTCP"),
                ref("axis2TransportSenderlocal"), ref("axis2TransportSender"),
                ref("axis2TransportSenderHTTPS")]
            phaseOrders =  [ref("axis2InPhaseOrder"),
                ref("axis2InFaultPhaseOrder"), ref("axis2OutPhaseOrder"),
                ref("axis2OutFaultPhaseOrder")]
            modules = ["addressing"]
        }
        
        "hd"(org.wso2.spring.ws.beans.ParameterBean) {
            name = "hotdeployment"
            value = "true"
        }
        "hu"(org.wso2.spring.ws.beans.ParameterBean) {
            name = "hotupdate"
            value = "true"
        }				
        "eMTOM"(org.wso2.spring.ws.beans.ParameterBean) {
            name = "enableMTOM"
            value = "true"
        }
        "eSwA"(org.wso2.spring.ws.beans.ParameterBean) {
            name = "enableSwA"
            value = "true"
        }
        "timeOut"(org.wso2.spring.ws.beans.ParameterBean) {
            name = "ConfigContextTimeoutInterval"
            value = "30000"
        }
        "stacktrace"(org.wso2.spring.ws.beans.ParameterBean) {
            name = "sendStacktraceDetailsWithFaults"
            value = "false"
        }
        "drillFaultReason"(org.wso2.spring.ws.beans.ParameterBean) {
            name = "DrillDownToRootCauseForFaultReason"
            value = "false"
        }
        "username"(org.wso2.spring.ws.beans.ParameterBean) {
            name = "userName"
            value = "admin"
        }
        "passwd"(org.wso2.spring.ws.beans.ParameterBean) {
            name = "password"
            value = "axis2"
        }
        "disRest"(org.wso2.spring.ws.beans.ParameterBean) {
            name = "disableREST"
            value = "true"
            locked = "false"
        }
	"axis2MsgReceiverIN"(org.wso2.spring.ws.beans.MessageReceiverBean) {
            mep = "http://www.w3.org/2004/08/wsdl/in-only"
            clazz = "org.apache.axis2.rpc.receivers.RPCInOnlyMessageReceiver"
	}
	"axis2MsgReceiverINOUT"(org.wso2.spring.ws.beans.MessageReceiverBean) {
            mep = "http://www.w3.org/2004/08/wsdl/in-out"
            clazz = "org.apache.axis2.rpc.receivers.RPCMessageReceiver"
	}
	"axis2MsgReceiverIN2"(org.wso2.spring.ws.beans.MessageReceiverBean) {
            mep = "http://www.w3.org/2006/01/wsdl/in-only"
            clazz = "org.apache.axis2.rpc.receivers.RPCInOnlyMessageReceiver"
	}
	"axis2MsgReceiverINOUT2"(org.wso2.spring.ws.beans.MessageReceiverBean) {
            mep = "http://www.w3.org/2006/01/wsdl/in-out"
            clazz = "org.apache.axis2.rpc.receivers.RPCMessageReceiver"
	}
	"axis2MsgFormatterURL"(org.wso2.spring.ws.beans.MessageFormatterBean) {
            contentType = "application/x-www-form-urlencoded"
            clazz = "org.apache.axis2.transport.http.XFormURLEncodedFormatter"
	}
	"axis2MsgFormatterForm"(org.wso2.spring.ws.beans.MessageFormatterBean) {
            contentType = "multipart/form-data"
            clazz = "org.apache.axis2.transport.http.MultipartFormDataFormatter"
	}
	"axis2MsgFormatterXML"(org.wso2.spring.ws.beans.MessageFormatterBean) {
            contentType = "application/xml"
            clazz = "org.apache.axis2.transport.http.ApplicationXMLFormatter"
	}
	"axis2MsgBuilderXML"(org.wso2.spring.ws.beans.MessageBuilderBean) {
            contentType = "application/xml"
            clazz = "org.apache.axis2.builder.ApplicationXMLBuilder"
	}
	"axis2MsgBuilderURL"(org.wso2.spring.ws.beans.MessageBuilderBean) {
            contentType = "application/x-www-form-urlencoded"
            clazz = "org.apache.axis2.builder.XFormURLEncodedBuilder"
	}
	"axis2MsgBuilderForm"(org.wso2.spring.ws.beans.MessageBuilderBean) {
            contentType = "multipart/form-data"
            clazz = "org.apache.axis2.builder.MultipartFormDataBuilder"
	}
	"axis2TransportReceiver"(org.wso2.spring.ws.beans.TransportReceiverBean) {
            name = "http"
            clazz = "org.apache.axis2.transport.http.SimpleHTTPServer"
            parameters = [port:"8888"]
	}
	"axis2TransportSender"(org.wso2.spring.ws.beans.TransportSenderBean) {
            name = "http"
            clazz = "org.apache.axis2.transport.http.CommonsHTTPTransportSender"
            parameters = [PROTOCOL:"HTTP/1.1", "Transfer-Encoding":"chunked"]
	}
	"axis2TransportSenderTCP"(org.wso2.spring.ws.beans.TransportSenderBean) {
            name = "tcp"
            clazz = "org.apache.axis2.transport.tcp.TCPTransportSender"
	}
	"axis2TransportSenderlocal"(org.wso2.spring.ws.beans.TransportSenderBean) {
            name = "local"
            clazz = "org.apache.axis2.transport.local.LocalTransportSender"
	}
	"axis2TransportSenderHTTPS"(org.wso2.spring.ws.beans.TransportSenderBean) {
            name = "https"
            clazz = "org.apache.axis2.transport.http.CommonsHTTPTransportSender"
            parameters = [PROTOCOL:"HTTP/1.1", "Transfer-Encoding":"chunked"]
	}
	"axis2AddressingPhase"(org.wso2.spring.ws.beans.PhaseBean) {
            name = "Addressing"
            handlers = [ref("addressingHandler")]
	}
	"addressingHandler"(org.wso2.spring.ws.beans.HandlerBean) {
            name = "AddressingBasedDispatcher"
            clazz = "org.apache.axis2.dispatchers.AddressingBasedDispatcher"
            orderPhase = "Addressing"
	}
	"axis2InPhaseOrder"(org.wso2.spring.ws.beans.PhaseOrderBean) {
            phaseOrderType = "InFlow"
            phases = [ref("axis2TransportPhase"), ref("axis2AddressingPhase"), ref("preDispatchPhase"), ref("InDispatchPhase")]
	}
        "InDispatchPhase"(org.wso2.spring.ws.beans.PhaseBean) {
            name = "Dispatch"
            clazz = "org.apache.axis2.engine.DispatchPhase"
            handlers = [ref("RequestURI"), ref("SOAPAction"), ref("RequestURIOperation"), ref("SOAPMessageBody"), ref("HTTPLocationBased")]
        }
	"axis2TransportPhase"(org.wso2.spring.ws.beans.PhaseBean) {
            name = "Transport"
            handlers = [ref("URIBasedDispather"), ref("ActionBasedDispatcher")]
	}
        "URIBasedDispather"(org.wso2.spring.ws.beans.HandlerBean) {
            name = "RequestURIBasedDispatcher"
            clazz = "org.apache.axis2.dispatchers.RequestURIBasedDispatcher"
            orderPhase = "Transport"
        }
        "ActionBasedDispatcher"(org.wso2.spring.ws.beans.HandlerBean) {
            name = "SOAPActionBasedDispatcher"
            clazz = "org.apache.axis2.dispatchers.SOAPActionBasedDispatcher"
            orderPhase = "Transport"
        }
	"RequestURI"(org.wso2.spring.ws.beans.HandlerBean) {
            name = "RequestURIBasedDispatcher"
            clazz = "org.apache.axis2.dispatchers.RequestURIBasedDispatcher"
	}
	"SOAPAction"(org.wso2.spring.ws.beans.HandlerBean) {
            name = "SOAPActionBasedDispatcher"
            clazz = "org.apache.axis2.dispatchers.SOAPActionBasedDispatcher"
	}
	"RequestURIOperation"(org.wso2.spring.ws.beans.HandlerBean) {
            name = "RequestURIOperationDispatcher"
            clazz = "org.apache.axis2.dispatchers.RequestURIOperationDispatcher"
	}
	"SOAPMessageBody"(org.wso2.spring.ws.beans.HandlerBean) {
            name = "SOAPMessageBodyBasedDispatcher"
            clazz = "org.apache.axis2.dispatchers.SOAPMessageBodyBasedDispatcher"
	}
	"HTTPLocationBased"(org.wso2.spring.ws.beans.HandlerBean) {
            name = "HTTPLocationBasedDispatcher"
            clazz = "org.apache.axis2.dispatchers.HTTPLocationBasedDispatcher"
	}
	"axis2InFaultPhaseOrder"(org.wso2.spring.ws.beans.PhaseOrderBean) {
            phaseOrderType = "InFaultFlow"
            phases = [ref("axis2AddressingPhase"), ref("preDispatchPhase"), ref("InFaultDispatchPhase")]
		
	}
        "InFaultDispatchPhase"(org.wso2.spring.ws.beans.PhaseBean) {
            name = "Dispatch"
            clazz = "org.apache.axis2.engine.DispatchPhase"
            handlers = [ref("RequestURI"), ref("SOAPAction"), ref("RequestURIOperation"), ref("SOAPMessageBody"), ref("HTTPLocationBased")]          	
        }
	"preDispatchPhase"(org.wso2.spring.ws.beans.PhaseBean) {
            name = "PreDispatch"
	}
	"axis2OutPhaseOrder"(org.wso2.spring.ws.beans.PhaseOrderBean) {
            phaseOrderType = "OutFlow"
            phases = [ref("messageOut")]
		
	}
	"axis2OutFaultPhaseOrder"(org.wso2.spring.ws.beans.PhaseOrderBean) {
            phaseOrderType = "OutFaultFlow"
            phases = [ref("messageOut")]
		
	}
	"messageOut"(org.wso2.spring.ws.beans.PhaseBean) {
            name = "MessageOut"
	}
    }
   
    def doWithApplicationContext = { applicationContext ->
        // TODO Implement post initialization spring config (optional)		
    }

    def doWithWebDescriptor = { xml ->
	def servlets = xml.'servlet'
	def servletMaps = xml.'servlet-mapping'
        servlets[servlets.size()-1] + {
            servlet {
                "servlet-name"("axis2")
                "servlet-class"("org.grails.axis2.GrailsAxis2Servlet")
                "load-on-startup"(1)
            }
        }
        servletMaps[servletMaps.size()-1] + {
            "servlet-mapping" {
                "servlet-name"("axis2")
                "url-pattern"("/axis2/*")
            }
	}
        servletMaps[servletMaps.size()-1] + {
            "servlet-mapping" {
                "servlet-name"("axis2")
                "url-pattern"("/services/*")
            }
	}
    }
	                                      
    def doWithDynamicMethods = { ctx ->
        // TODO Implement registering dynamic methods to classes (optional)
    }
	
    def onChange = { event ->
        // TODO Implement code that is executed when this class plugin class is changed  
        // the event contains: event.application and event.applicationContext objects
    }
                                                                                  
    def onApplicationChange = { event ->
        // TODO Implement code that is executed when any class in a GrailsApplication changes
        // the event contain: event.source, event.application and event.applicationContext objects
    }
}
