/*
 * Copyright 2004-2005 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import org.codehaus.groovy.grails.commons.ControllerArtefactHandler;
import org.codehaus.groovy.grails.commons.GrailsApplication;
import org.codehaus.groovy.grails.commons.GrailsClass;
import org.codehaus.groovy.grails.web.mapping.UrlMappingInfo;
import org.codehaus.groovy.grails.web.mapping.UrlMappingsHolder;
import org.codehaus.groovy.grails.web.mapping.exceptions.UrlMappingException;
import org.codehaus.groovy.grails.web.servlet.GrailsApplicationAttributes;
import org.codehaus.groovy.grails.web.servlet.WrappedResponseHolder;
import org.codehaus.groovy.grails.web.servlet.mvc.GrailsWebRequest;
import org.codehaus.groovy.grails.web.util.WebUtils;
import org.springframework.web.context.request.RequestContextHolder

import org.codehaus.groovy.grails.commons.GrailsControllerClass
import org.codehaus.groovy.grails.web.pages.GroovyPagesTemplateEngine
import org.grails.include.ImportResponseWrapper
import org.grails.include.IncludeRequestWrapper
import org.grails.include.IncludeWebUtils;
/**
 *
 * @author Daniel Latorre
 */
class IncludeTagLib {
    private static final String GSP_SUFFIX = ".gsp"
    private static final String JSP_SUFFIX = ".jsp"
    static namespace = "inc"

    GroovyPagesTemplateEngine groovyPagesTemplateEngine

    def include = { attrs, body ->
        if(attrs.url){
            includeFromUrl(attrs.url)
        }else if(attrs.controller){
            includeFromController(attrs.controller, attrs.action, attrs.params)
        }else{
            throw new RuntimeException("Required attributes not present, controller or url attributes")
        }
    }
    /**
     * @deprecated use <inc:include url="yoururl"/>
     */
    def includeUrl= { attrs, body ->
        includeFromUrl(attrs.url)
    }
    /**
     * @deprecated use <inc:include controller="yourcontrollername" action="youraction" params="yourparamsmap"/>
     */
    def includeController= { attrs, body ->
        includeFromController(attrs.controller, attrs.action, attrs.params)
	}

	private void includeFromUrl(url) {
        int end = url.indexOf("?")
        if(end>-1){
            String uri = url.substring(0,end)
            if(uri.charAt(uri.length()-1)!=WebUtils.SLASH){
                url = uri + WebUtils.SLASH + url.substring(end)
            }
        }

        ImportResponseWrapper includeResponse = new ImportResponseWrapper(response)
        IncludeRequestWrapper includeRequest = new IncludeRequestWrapper(request,url)

        GrailsWebRequest webRequest = new GrailsWebRequest(includeRequest,  includeResponse, servletContext)

        GrailsControllerClass controllerClass = grailsApplication.getArtefactForFeature(ControllerArtefactHandler.TYPE, url)
        if(controllerClass){
            webRequest.getParams().put(GrailsControllerClass.CONTROLLER,controllerClass.getName())
        }
        request.setAttribute(GrailsApplicationAttributes.WEB_REQUEST,webRequest)
        RequestContextHolder.setRequestAttributes(webRequest)
        if(!doFilterInternal(includeRequest,includeResponse,url)){
            def rd = servletContext.getRequestDispatcher(url)
            rd.include(includeRequest, includeResponse)
        }
        def result = includeResponse.getString()
        if(result==null){
            throw new RuntimeException("Exception ocurred including ${url}, content is null")
        }
        out << result
    }

	private void includeFromController(controller,action,params){
        params = params?params:[:]

        def urlMappings = grailsAttributes.getApplicationContext().getBean("grailsUrlMappingsHolder")
        def mapping = urlMappings.getReverseMapping(controller,action,params)
        def url = mapping.createRelativeURL(controller, action, params, request.characterEncoding)
        IncludeRequestWrapper request = new IncludeRequestWrapper(request,url)
        ImportResponseWrapper reponse = new ImportResponseWrapper(response)

        GrailsWebRequest webRequest = new GrailsWebRequest(request,  response, servletContext)

        webRequest.getParams().putAll(params)
        webRequest.getParams().put(GrailsControllerClass.CONTROLLER,controller)
        webRequest.getParams().put(GrailsControllerClass.ACTION,action)

        GrailsControllerClass controllerClass = grailsApplication.getArtefactByLogicalPropertyName(ControllerArtefactHandler.TYPE, controller)
        def result
        if(controllerClass) {
            request.setAttribute(GrailsApplicationAttributes.WEB_REQUEST,webRequest)
            RequestContextHolder.setRequestAttributes(webRequest)
            doFilterInternal(request,reponse,url)
            result = reponse.getString()
        }

        if(result==null){
            throw new RuntimeException("Exception ocurred including ${url}, content is null")
        }
        out << result
	}

    private boolean doFilterInternal(def request, def response,def uri){
        GrailsWebRequest webRequest = (GrailsWebRequest)request.getAttribute(GrailsApplicationAttributes.WEB_REQUEST)
        UrlMappingsHolder holder = WebUtils.lookupUrlMappings(servletContext)
        GrailsApplication application = WebUtils.lookupApplication(servletContext)


        UrlMappingInfo[] urlInfos = holder.matchAll(uri)
        WrappedResponseHolder.setWrappedResponse(response)

        boolean dispatched = false;
        try {
            for (int i = 0; i < urlInfos.length; i++) {
                UrlMappingInfo info = urlInfos[i]
                    if(info!=null) {
                        info.configure(webRequest)
                        String action = info.getActionName() == null ? "" : info.getActionName()
                        final String viewName = info.getViewName()
                        if (viewName == null) {
                            String controllerName = info.getControllerName()
                            int begin= uri.indexOf("?");
                            if(begin>-1){
                                uri = uri.substring(0,begin)
                            }
                            GrailsClass controller = application.getArtefactForFeature(ControllerArtefactHandler.TYPE, uri)
                            if(controller == null)  {
                                continue;
                            }
                        }

                        dispatched = true;



                        if(viewName == null || viewName.endsWith(GSP_SUFFIX) || viewName.endsWith(JSP_SUFFIX)) {
                            String includedUrl = IncludeWebUtils.includeRequestForUrlMappingInfo(request, response, info,webRequest)
                            if(log.isDebugEnabled()) {
                                log.debug("Matched URI ["+uri+"] to URL mapping ["+info+"], included ["+includedUrl+"] with response ["+response.getClass()+"]")
                            }
                        }
                        else {
                            if(!groovyPagesTemplateEngine) throw new IllegalStateException("Property [groovyPagesTemplateEngine] must be set!")
                            def engine = groovyPagesTemplateEngine
                            def r = engine.getResourceForUri(viewName + ".gsp")
                            def t = engine.createTemplate( r )
                            t.make().writeTo(response.getWriter())
                        }
                        break;
                    }
            }
        }
        finally {
            WrappedResponseHolder.setWrappedResponse(null);
        }

        return dispatched
    }
}