package org.grails.include;/*
 * Copyright 2004-2005 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import org.codehaus.groovy.grails.web.mapping.UrlMappingInfo;
import org.codehaus.groovy.grails.web.mapping.UrlMappingsHolder;
import org.codehaus.groovy.grails.web.servlet.mvc.GrailsWebRequest;
import org.codehaus.groovy.grails.web.util.WebUtils;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.apache.commons.lang.StringUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import java.io.IOException;
import java.util.Collections;
import java.util.Map;

/**
 *
 * @author Daniel Latorre
 */
public class IncludeWebUtils {

    /**
     * Looks up the UrlMappingsHolder instance
     *
     * @return The UrlMappingsHolder
     * @param servletContext The ServletContext object
     */
    public static UrlMappingsHolder lookupUrlMappings(ServletContext servletContext) {
        WebApplicationContext wac =
                WebApplicationContextUtils.getRequiredWebApplicationContext(servletContext);

        return (UrlMappingsHolder)wac.getBean(UrlMappingsHolder.BEAN_ID);
    }
    
    public static String includeRequestForUrlMappingInfo(HttpServletRequest request, HttpServletResponse response, UrlMappingInfo info,GrailsWebRequest webRequest) throws ServletException, IOException {
        return includeRequestForUrlMappingInfo(request, response, info, Collections.EMPTY_MAP,webRequest);
    }

    public static String includeRequestForUrlMappingInfo(HttpServletRequest request, HttpServletResponse response, UrlMappingInfo info, Map model,GrailsWebRequest webRequest) throws ServletException, IOException {
        String includeUrl = WebUtils.buildDispatchUrlForMapping(info);
        RequestDispatcher dispatcher = request.getRequestDispatcher(includeUrl);
        populateWebRequestWithInfo(webRequest, info);

        WebUtils.exposeForwardRequestAttributes(request);
        WebUtils.exposeRequestAttributes(request, model);
        dispatcher.include(request, response);

        return includeUrl;
    }
    
    //Duplicated on org.codehaus.groovy.grails.web.util.WebUtils; 
    private static void populateWebRequestWithInfo(GrailsWebRequest webRequest, UrlMappingInfo info) {
        if(webRequest != null) {
            final String viewName = info.getViewName();

            if (viewName == null) {
                webRequest.setControllerName(info.getControllerName());
                webRequest.setActionName(info.getActionName());
            }

            String id = info.getId();
            if(!StringUtils.isBlank(id))webRequest.getParams().put(GrailsWebRequest.ID_PARAMETER, id);

            // Add all the parameters from the URL mapping.
            webRequest.getParams().putAll(info.getParameters());
        }
    }
}
