package org.grails.include;/*
 * Copyright 2004-2005 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import java.util.*;
import org.codehaus.groovy.grails.web.util.WebUtils;

/**
 *  
 * @author Daniel Latorre
 */
public class IncludeRequestWrapper extends HttpServletRequestWrapper {

    private String uri;
    private String queryString;
    private Map<String,String> params;

    public IncludeRequestWrapper(HttpServletRequest httpServletRequest,String uri) {
        super(httpServletRequest);
        params = new HashMap<String,String>();
        int begin= uri.indexOf("?");
        if(begin>-1){
            this.uri = getContextPath()+uri.substring(0,begin);            
            queryString = uri.substring(begin+1);
            String[] parametersArr = queryString.split("&");
            for(int i=0;parametersArr.length>i;i++){
                String[] par = parametersArr[i].split("=");
                if(par.length==2){
                    params.put(par[0],par[1]);
                }
            }
        }


    }

    public String getMethod() {
        return "GET";
    }
    
    public String getQueryString() {
        return queryString;
    }

    public String getRequestURI() {
        return uri;
    }

    public StringBuffer getRequestURL() {
        StringBuffer url= new StringBuffer(getContextPath());
        url.append(uri);
        return url;
    }    

    public String getParameter(String s) {
        return params.get(s);
    }

    public Enumeration getParameterNames() {
        return Collections.enumeration(params.keySet());        
    }     

    public Map getParameterMap() {
        return params;  //To change body of implemented methods use File | Settings | File Templates.
    }

}
