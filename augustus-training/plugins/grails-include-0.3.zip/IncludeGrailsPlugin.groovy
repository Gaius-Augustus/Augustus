
class IncludeGrailsPlugin {
    def version = "0.3"
    def author = "Daniel Latorre"
    def authorEmail = "dani@danilat.com"
    def title = "This plugin adds include behaviour to Grails application."
    def documentation = "http://grails.org/Include+Plugin"

}